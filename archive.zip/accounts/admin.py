from django.contrib import admin
from .models import OtpCode

admin.site.register(OtpCode)